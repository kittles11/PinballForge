# PinballForge 运营 × 美术完善计划

> 版本：v1.1（2026-09-07 再同步）
> 视角：游戏运营 + 美术。技术架构与代码级问题见根目录 `PROJECT_ANALYSIS.md`（8/27 只读分析 + 09-07 校准勘误），本文不重复。
> 方法论：《游戏设计的100个原理》体系（核心循环 / 心流 / 80-20 / 约束三角 / 主题一致性 / 视觉引导 / Fitts / Hick / 奖惩系统 / 动态难度）。
> 维护方式：每完成一项在对应表格打勾并注明日期；里程碑验收标准不允许口头放宽。
> **📌 最后校准：2026-09-07**——§1 现状表已按当日自检刷新；历史正文若与 `tools/selfchecks/` 冲突，以自检为准。

---

## 1. 现状盘点（2026-09-07 刷新）

**一句话**：核心循环成立且防御纵深扎实（35 个自检全绿护城河），表现层与运营层已从空白补到可用；当前主战场是协同深度（球×钉×槽×卡化学反应）与数值后期曲线。

| 维度 | 已有 | 缺口 |
|---|---|---|
| 玩法 | 7 球种（冰球已闭环：易伤 0.25 + 商店上架）、3 漏斗、4 钉种+镀金钉、5 敌种+精英词缀、16+6 卡、5 遗物、Boss 三周期、弹珠×敌人直伤、碎冰/寒霜导热/镀金赏金协同、50 章、Meta 树、DDA | 球×钉×槽×卡更深层协同（组合包第二批）、后期曲线实机校准 |
| 视觉 | 全矢量 ArtTheme + IconLib 25 图标 + 9 张程序化贴图、FxManager 分层特效、MotionStreak 拖尾、HitStop/震屏 | 敌人差异仍靠颜色+缩放，无帧动画 |
| 音频 | 撞钉直播池音高爬升 + Web Audio 合成特效 + 程序化 BGM（Boss 打击层/胜负 stinger/模态 ducking）+ 击杀反馈音 | 音效文件仍少（合成主导是刻意选择） |
| 运营 | Analytics 埋点壳、每日任务、签到、每日挑战、激励视频点位、AdService | 埋点后端上报（缓冲壳够用到软启动前） |
| 上线阻塞 | ~~音频打包路径~~ 已修复；~~商店深度~~ 二期已上（稀有位+刷新）；~~多分辨率验证~~ 静态审计+自检已上（docs/RESOLUTION_AUDIT.md） | 平台 SDK、隐私合规、多分辨率真机抽验（软启动前） |

## 2. 产品定位（用户中心设计）

| 项 | 结论 | 依据 |
|---|---|---|
| 平台 | **微信/抖音小游戏优先，H5 兜底** | localStorage 存档、HTML5 Audio、竖屏 720×1280 fitHeight、无原生痕迹 |
| 用户 | 休闲+轻肉鸽；单局 5-10 分钟 | 3 波/关的碎片结构；对标 Peglin、弓箭传说 |
| 商业化 | **IAA（激励视频）为主 + 轻混变**，M4 前不做 IAP | 单机肉鸽无付费深度；广告位成本低、风险小 |
| 北极星 | 次留 ≥35%、7 留 ≥15%、人均广告 ≥2 次/日 | 软启动验收线（M4） |

**约束三角（快/便宜/好占俩）**：本计划选择**快+便宜**。砍掉的：IAP、体力系统、全服排行榜、外包美术。保住的：风格概念一致性、首 10 分钟体验、埋点完整性。

## 3. 运营计划

### 3.1 留存漏斗（原理：锚定效应 + 奖惩系统）

| 节点 | 现状 | 动作 | 原理 |
|---|---|---|---|
| D0 首 10 分钟 | TutorialManager 已有 | 前 3 关手工编排：1-1 纯普通怪教学、1-2 必掉雷球卡（首个爽点）、1-3 必出金币槽（经济教学） | 锚定效应：首印象锚定后续判断 |
| D1 次留 | Meta 12 条×5 级三条根深度链（castle→{orbCap→boardLab, startShield, siege} / gold→{bargain, shard} / damage→{orbLab, insight→forbiddenPack}），已含版型 D/E + 禁忌三档（奇点/猎神/不朽要塞）+ 球种三档（等离子/熔核/吸血）跨局解锁；锻造区 📖 解锁总览预览切换 | 真机校准平衡（护盾分布 / 三球种手感 / 商道·炮台·吸血·不朽收益） | 随机+固定奖励混合建立信任 |
| D3-D7 | 无 | 每日任务 3 条/天（击杀 N 只、使用 X 球、观看 1 次广告）；每日挑战关（固定 seed + 好友排行）；7 日签到 | 节奏控制：可预期固定奖励打底 |
| D30 长线 | 50 章线性公式 | 每 5 章一个视觉主题 + 1 种新机制敌人；50 章后无尽模式 | 每约 7 分钟一个新元素 |

### 3.2 变现点位（先埋 UI 点位，M4 接 SDK）

激励视频（按预期收益排序，全部玩家主动触发，不做强制插屏）：

1. **死亡复活**（城堡沦陷后看广告原地满血复活 1 次/局）
2. **结算双倍碎片**（`MetaManager.grantRunReward` 后追加）
3. **三选一免费刷新**（`drawWeightedCards` 已支持重抽）
4. 商店免费刷新 / 金币礼包

### 3.3 动态难度（Buster 原则：暗中调整，玩家不可感知）

- 监控：连续失败次数、单波耗时、放弃率
- 触发：连续 3-5 次失败 → 敌 HP -5~10% / 出怪间隔 +10%
- 反向：连续 3 次零压力通过 → 回调
- 落点：`LevelManager.getWaveConfig()` 是唯一数值出口，在此加一个存档内的隐藏修正系数即可
- **红线**：不显示"难度已降低"字样；保留通关成就感

### 3.4 版本节奏（项目规划）

软启动（1000 人灰度）→ 数据迭代 → 全量。内容管线：**50 章算法生成保留骨架，前 10 章手工调优保体验**，后续章节只做新元素注入（新敌人/新钉板/新卡），不做关卡重做。

## 4. 美术计划

### 4.1 风格方向（主题一致性——锁定后才允许开工任何资产）

**方向：蒸汽朋克锻造工坊**。理由：游戏名 PinballForge 与核心机制（精铸碎片⚒、弹珠打磨、锻造 Meta）都是"锻造"，机制×题材×视觉三方协同。

- **关键词**：铜与铁的暖金属、炉火光、铆钉、齿轮、坩埚弹珠
- **色板基线**（待概念图定稿）：
  - 环境/底色：锻铁深灰 `#2B2D31` + 铜棕 `#B87333`
  - 火系：熔岩橙 `#FF6B35`；电系：电光青 `#00E5FF`；冰系：冰晶蓝 `#7FD8FF`；中立：金币 `#FFD700`
  - **颜色语义铁律**：火=橙、电=青、冰=蓝白、中立=金，必须贯穿卡牌边框、球体、开火特效、漏斗槽四层，玩家不读文字即可构建策略（原理：主题协同 1+1>2）
- **概念图**（人工产出，1 张即可）：主场景全景含城堡+钉板+漏斗+敌人，作为所有后续资产的比对基准
- 待选参考：SteamWorld Dig 的工坊质感、Peglin 的"桌面玩具感"

### 4.2 占位替换 P0 清单（M1 执行，完整规格见附录 B）

| 现状 | 替换物 | 数量 |
|---|---|---|
| emoji 敌人 🔴🛡️⚡🦠👹 | 敌人立绘（含受击闪白 tint，无需单独帧） | 5 |
| emoji 遗物 ⛏️💥🛡️🌊👑 | 遗物图标，统一描边风格 | 5 |
| 卡牌纯文字 | 卡面模板（普通/稀有/史诗 3 套边框）+ 12 卡图。**史诗边框必须做出"贵"**（锚定效应拉高抽卡感知价值） | 模板 3 + 卡图 12 |
| Graphics 色块场景 | 主场景背景 720×1280 ×1 + 钉板框 + 城堡 + 3 漏斗槽 | 6 |

低成本路线：Kenney.nl / itch.io CC0 改造 + AI 立绘统一色板，先不外包。

> **✅ 已实施（2026-09-02）— 零美工图标路线落地**：
> - 弃用 Kenney 通用件路线（扁平亮色风与深靛蓝+霓虹主题违和）；遗物/词缀/球种/UI 徽章图标改为
>   **自绘矢量路径数据 + 运行时 Graphics 填充 + ArtTheme 染色**（`Core/IconLib.ts` 25 枚注册图标 +
>   `Core/IconGlyph.ts` 解析器，零图片资产、零包体开销、跨平台字形一致）。`selfcheck-icon-ui.ts`
>   机器校验注册表健康 / 引用完整性 / 渲染文案 emoji 禁令。遗物与词缀 emoji 数据字段已切换为注册表名；
>   `ENEMY_TYPE_STATS.icon` 与 `CardArchetype` 显示名仍为 emoji（仅日志/未接线遗留数据，不渲染）。
> - Juice 项落地：`Core/HitStop.ts` 物理冻结顿帧（重炮开火 40ms / Boss 出场 90ms）、漏斗槽
>   凹陷+呼吸光晕可供性（`FunnelSlot.ensureRecess/ensureHaloPulse`）、Boss 出场演出（爆闪+冲击环+
>   震屏+宣告跳字，注意力分层顶端）、`Core/UiKit.ts` 凸起+阴影按钮语言（商店/背包）、背景齿轮
>   暗纹氛围层（`BackdropFx`）。全按钮凸起+史诗卡面模板仍待后续批次。
>
> **✅ 已实施（2026-09-03）— 场景件与卡面模板（P0 清单余项收尾）**：
> - **城堡精绘**（`CastleController.ensureCastleArt`）：双塔+主楼雉堞锻铁要塞 + 暗铜饰带 + 铆钉 +
>   拱门基座，替代场景遗留的单色方块 Sprite（旧 `#262928` 灰绿块已随组件销毁）；炉火窗光
>   亮度 = 血量比例 × 正弦颤动（`update` 驱动）——城堡被打残时炉火渐熄，血条的叙事化表达；
>   爆炸演出走既有「无 Sprite → 抖动+膨胀+缩没」兜底，无需改动。
> - **卡面稀有度边框**（`UiKit.cardFrame/rarityTier/rarityColor` + `RewardDialog.setCardLabel`）：
>   普通=铁灰细线 / 稀有=电光青双线 / **史诗=金双线+四角钻石饰+EpicGlow 金晕呼吸**（贵气=金+饰+动
>   三层合成，锚定效应）；卡面左缘加流派色条（熔岩橙红/电光冰蓝/冰封霜白/中立金，全取 ArtTheme）；
>   `CardArchetype` 枚举显示名去 emoji。
> - **按钮凸起收尾**：每日任务领取/关闭按钮接入 `raisedButton`（接入面达 3 个弹窗：
>   商店/背包/每日任务，selfcheck-icon-ui 规则 G 清点）。
> - selfcheck-icon-ui 扩至规则 A~G（图标健康/引用完整性/emoji 禁令/HitStop 护栏/城堡美术/
>   稀有度边框/按钮统一）。
>
> **✅ 已实施（2026-09-03 续）— 生成贴图接线（AI 图入项目）**：
> - `Core/TexCache.ts` 统一贴图缓存加载器（失败结果也缓存 + 并发挂队），全项目「贴图优先、
>   矢量兜底」范式：城堡 `turret_forge_castle`（兜底=矢量要塞）、五类敌人 `enemy_<type>`
>   （兜底=色块圆+剪影，落地投影保留；立绘不再按类型染色，受击/冰封 tint 照常生效）、
>   卡面 `card_frame_<tier>` 三档（兜底=UiKit 稀有度边框，FrameImg 垫底不遮文字）。
> - selfcheck-icon-ui 规则 H：9 张贴图落盘/登记一致性 + 消费点接线 + **真 PNG 拦截**——
>   当前生成器导出的是 JPEG 内容改 .png 扩展名（透明底被烧成棋盘格预览底），上线前必须
>   从生成器重导「透明背景 PNG」覆盖同名文件（编辑器已按 sprite-frame 导入，覆盖即自动重导）。
> - 包体提示：当前单张 ~2MB × 9 张 ≈ 18MB，微信主包 4MB 预算必爆；重导出时敌人按 ~128-192px、
>   城堡 ~256px、卡框 ~640px 宽即可，总体积应压到 1MB 内（配合 pngquant/tinyPNG 更佳）。
>
> **✅ 已实施（2026-09-03 续 2）— 生成图本地抠图入库 + 竖版卡面**：
> - 第二批生成图为**纯白背景**全尺寸 PNG（12.4MB/张）。`tools/cutout-checkerboard.py`（v3-final）
>   本地抠图：白键控（min≥238）→ 边界连通泛洪（立绘内部高光不透）→ 2px 去晕 → 内容 bbox 裁剪
>   → 按版位等比缩放（敌 220 / Boss 260 / 城 340 / 卡框 480 宽）→ 回写真 RGBA PNG。
>   逐张目检验收：银甲骑士/熔岩人/幽灵/城堡/卡框均无误伤、无白边残留。总体积 12.4MB×9 → 1.35MB。
> - 卡框确认为**竖版卡面设计**（~2:3）→ 三选一/遗物宝箱卡改竖版布局：210×300（代码钉位
>   三连排 -210/0/+210），框窗文字区 148×165（流派·稀有度/名称/说明三段式），框体空白内窗
>   由脚本填充面板深色（epic）或原生透明（common/rare）；遗物宝箱卡复用史诗金框 + 顶部遗物图标。
> - `textures/11`、`textures/resources` 杂讯源目录移出 assets 至 `raw-art-src/`（防 Cocos 误导入）。
> - selfcheck-icon-ui 规则 H 全绿（9 张真 PNG）；卡面接线断言同步竖版尺寸。

### 4.3 Juice 与视觉引导（M1-P1）

- **可供性**：漏斗槽改"凹陷+光晕"暗示可入槽；全按钮统一凸起+阴影（原理：视觉引导/可供性）
- **注意力捕获优先级**：Boss 出场（运动+意外）> 漏斗命中（运动）> 金币飘字（吸引力）。当前所有反馈同权重，玩家不知道看哪——用强度分层解决
- **黄金比例**：HUD 按 φ 分割（状态区:战斗区 ≈ 1:1.618，720×1280 下状态区约 310px 高）

### 4.4 UI/UX（Fitts / Hick）

- 三选一保持 3 张（Hick 最优 3-6 ✅）；卡牌热区加大，放屏幕下部 40% 拇指区（Fitts）
- 弹窗统一 1 主按钮 + 1 次按钮
- 现有 DeckButtonController 的轻点/拖拽区分保留

### 4.5 音频（M1-P1）

- 音效包 9 个 + BGM 2 首（战斗/结算各一），优先免费库起步（规格见附录 B）
- 现有 Web Audio 合成音保留为**降级兜底**，不做删除

## 5. 里程碑（运营 × 美术交叉排期）

| 里程碑 | 时长 | 内容 | 验收标准（不允许口头放宽） |
|---|---|---|---|
| **M1 表现力切片** | 2 周 | 4.1 概念图定稿 → 附录 B P0 资产全量替换 → 4.3 Juice 特效 → 音效包接入 | 录屏给 3 个未接触过的人看，"想玩"≥2 人；任意截图看不出是色块原型 |
| **M2 运营基建** | 2 周 | 附录 A 埋点全量 + 4 个广告点位 UI（空接）+ 每日任务系统 + Meta 扩至 8 条 | 测试包内可见完整漏斗数据上报；D1 钩子上线 |
| **M3 调优** | 2 周 | 前 10 章手工难度曲线 + 动态难度逻辑（3.3）+ 全卡池加倍/减半平衡轮 | 首日通过率曲线无悬崖；无弃选率 >80% 的卡 |
| **M4 软启动** | 2 周+ | 1000 人灰度 → 按数据迭代留存与广告位 → 接入正式 SDK | 次留≥35%，人均广告≥2 次/日，崩溃率 <1% |

依赖关系：M1 概念图是全美术资产的前置，**先锁风格再开工**；M2 埋点字段设计已在附录 A 定稿，可与 M1 并行开发。

## 6. 下一步执行顺序（Act 落地清单）

1. ✅ 本计划文档落地（本文档）
2. ✅ P0 音频打包路径修复——**核实已于此前迭代完成**（AudioManager.init 走 `resources.load('audio/ding')`，`assets/resources/audio/ding.mp3` 就位，含兜底与合成降级）
3. ⬜ 附录 B 规格表交美术/AI 产线开工 P0 资产（敌人 5 + 遗物 5 + 卡牌模板 3 + 场景件 6）
4. ✅ 附录 A 埋点接口壳——已落地 `Core/Analytics.ts`（track = console 输出 + localStorage 环形缓冲 ≤200 条，M4 换 SDK 只改 track 内部；自检 `selfcheck-analytics.ts` 全过）
5. ✅ M2 每日任务数据模型——已落地 `Core/DailyTaskManager.ts`（3 条/天、跨日重置覆盖长会话挂后台过夜场景、奖励经 `MetaManager.addShards` 入账碎片；自检 `selfcheck-daily-tasks.ts` 全过；UI 面板与上报挂钩点留 M2 接线）

---

## 附录 A：埋点事件表（挂钩点已映射到现有代码）

抽象层：`Analytics.track(event: string, props?: object)`，先 console 输出 + localStorage 环形缓冲（≤200 条，调试用），M4 换微信/抖音 SDK 同签名替换。**（已落地：`Core/Analytics.ts`，2026-08-31）**

| 事件名 | 字段 | 挂钩点（现有代码位置） | 用途 |
|---|---|---|---|
| `session_start` | ts | MainScene 首个 onLoad | 会话数/DAU |
| `run_start` | chapter, level | ResultDialog 重开入口 / 首局 | 单局漏斗分子 |
| `wave_start` | chapter, level, wave | WaveManager 波次开始 | 进度深度 |
| `wave_clear` | chapter, level, wave, durationSec | WaveManager 波末 | 波难度校准 |
| `run_fail` | chapter, level, wave, castleHpLeft, runDurationSec | ResultDialog GameOver 分支 | **卡点定位 → 动态难度输入** |
| `run_win` | chapter, level, runDurationSec | ResultDialog Victory 分支 | 通过率 |
| `card_offer` | offers: string[3], chapter | RewardDialog 弹出时 | 卡牌曝光 |
| `card_pick` | pickedId, offers, usedRefresh | RewardDialog 选择回调 | 弃选率 → 冷门卡重做 |
| `relic_offer` | types: string[2] | RewardDialog 5/10 关二选一 | 遗物曝光 |
| `shop_view` / `shop_buy` | itemId, price, goldBalance | ShopDialog 打开 / 购买成功回调 | 商店转化与定价 |
| `meta_buy` | upgradeId, toLv, price | MetaManager.buy() 成功分支 | meta 消耗节奏 |
| `run_end` | result, shardsEarned, runDurationSec | MetaManager.grantRunReward() 后 | 单局时长分布（目标 5-10 分钟） |
| `ad_show` / `ad_complete` | placement | M4 广告 SDK 接入后 | 变现漏斗 |
| `daily_task_progress` | taskId, progress, claimed | M2 新增系统 | 任务完成率 |

埋点红线：只带数值与 id，**不采集任何个人身份信息**；事件名与字段名一旦上线不改名（只增不改）。

## 附录 B：美术资产规格表（P0/P1 全量）

**通用规范**
- 格式 PNG-32（透明底）；单图 ≤256KB；源文件存 `assets/art/source/`（不入构建）
- 命名：snake_case，前缀按类别（enemy_/relic_/card_/orb_/fx_/sfx_/bgm_）
- 交付目录：`assets/art/sprites/{enemies,relics,cards,scene,orbs}`；音频 `assets/audio/{sfx,bgm}`
- 图集：Cocos 自动图集按 UI 界面分组（battle / dialog / reward 三组），碎图禁入构建

| 资产 | 文件名 | 尺寸(px) | 数量 | 级别 | 备注 |
|---|---|---|---|---|---|
| 敌人立绘 | enemy_normal / _shield / _speed / _slime / _boss | 128×128 | 5 | P0 | 受击闪白用 tint 不需单独帧；Boss 另需出场待机 2 帧 |
| 遗物图标 | relic_gold_miner / _high_explosive / _thorn / _tidal / _crown | 96×96 | 5 | P0 | 统一金属描边 |
| 卡牌边框 | card_frame_common / _rare / _epic | 240×336 | 3 | P0 | 史诗边框做出"贵"（烫金+光效），锚定感知价值 |
| 卡面图标 | card_icon_<12 张卡 id> | 96×96 | 12 | P0 | 按色板四色语义 |
| 场景背景 | bg_main | 720×1280 | 1 | P0 | 预留顶部 310px 状态区（φ 分割） |
| 钉板框 | pegboard_frame | 720×560 | 1 | P0 | 木钉/乘倍/炸药/刷新钉孔位四态贴图另计 4×32 |
| 城堡 | castle | 128×160 | 1 | P0 | 需血条底座；受击抖动已有 CameraShake |
| 漏斗槽 | funnel_heavy / _ice / _gold | 96×96 | 3 | P0 | 凹陷+光晕可供性设计 |
| 弹珠 | orb_normal / _lightning / _lava / _frost | 64×64 | 4 | P1 | 附带拖尾贴图 1（32×32 渐隐条） |
| 粒子贴图 | fx_dot / fx_spark | 32×32 | 2 | P1 | Cocos 2D 粒子复用，不进图集 |
| 音效 | sfx_peg_hit / _funnel / _fire_normal / _fire_lightning / _fire_lava / _fire_frost / _buy / _win / _lose | mp3/ogg ≤100KB/个 | 9 | P1 | 保留 Web Audio 合成作降级 |
| BGM | bgm_battle / bgm_result | ogg 30-60s 循环 | 2 | P1 | 战斗 1 首、结算 1 首 |

**P0 合计 35 张图**，AI 辅助产线日产能约 8-10 张，M1 两周内含返工可完成。

## 附录 C：历史决策记录

| 日期 | 项 | 结论 |
|---|---|---|
| 2026-08-27 | PROJECT_ANALYSIS.md 标记 P0 音频路径风险 | **已于后续迭代修复**：AudioManager.init() 三层保障（resources.load → 旧路径兜底 → Web Audio 合成降级），该 P0 关闭 |
| 2026-08-31 | 商业化模式 | IAA 为主，IAP 推迟至软启动数据之后 |
| 2026-08-31 | 美术方向 | 蒸汽朋克锻造工坊（主题一致性），奇幻/赛博备选否决 |
| 2026-08-31 | M2 运营基建数据层 | `Core/Analytics.ts`（埋点壳）+ `Core/DailyTaskManager.ts`（每日任务模型）落地，各带纯 Node 自检（selfcheck-analytics / selfcheck-daily-tasks，hook 运行）；每日任务奖励经 `MetaManager.addShards` 入账碎片；任务面板 UI 与进度上报挂钩点留 M2 接线 |
| 2026-09-02 | 构筑闭环 + Meta 树（方向 2/3） | **应答卡**：破盾者/清剿令/猎首契约 3 张，各克制一类新机制（盾/召唤/精英），经 `EnemyController` 静态倍率挂 `takeDamage`，把"敌人侧机制"连回"构筑侧选择"。**Meta 解锁树**：`META_PREREQS` 前置门控，新增子轨 碎片收藏（需开局资金 Lv3，结算碎片 +15%/级）与 战术洞察（需弹珠打磨 Lv3，经 `enforceRarityFloor` 纯函数对三选一施加稀有度地板 Lv1 稀有/Lv3 史诗）；锻造区压缩 6 行、未解锁行显示 🔒 前置。自检 `selfcheck-meta-cards.ts`（24 项），全套 23/23 绿 |
| 2026-09-02 | Meta 树扩至 8 轨（方向 3 续） | 三条深度链：castle→**弹珠槽扩容**（牌库有效容量 8→最多 13，`DeckManager.maxDeckSize` 吃 `getOrbCapBonus`）→**钉板实验台**（Lv1/Lv3 解锁版型 D/E 入随机池，`activePegLayouts`；新版型经"无相邻等长行 + 复用既有相邻行对"构造保证无直落不变量，`selfcheck-peg-layouts` worstGap 校验通过）；gold→碎片收藏；damage→战术洞察→**禁忌卡包**（Lv1/Lv3 解锁 聚能奇点/猎神契约 两张 `FORBIDDEN_CARDS` 跨局专属卡并入抽卡池）。锻造区改双列 4×4（单列 8 行放不下 180px 带）。新球种跨局解锁因需新物理行为、风险高，明确留后续。全套 23/23 绿 |
| 2026-09-02 | 第 5 球种 + 10 轨（方向 2/3 终） | **新球种「等离子球」**（`OrbType.Plasma=4`）：签名机制**无视铁甲格挡与 Boss 坚盾**（`takeDamage` 两处 `orbType !== Plasma` 放行），代价是伤害吞吐更低（起始 30<40、每钉 +12<15，防"无视护盾"变严格占优）；经新 meta 轨**球种工坊**（damage←Lv2）解锁其 `AddOrb` 卡入池。**战备护盾**（castle←Lv2）开局要塞护盾 +15/级（`CastleController.onLoad`）。跨局卡泛化 `FORBIDDEN_CARDS`→`META_UNLOCKED_CARDS`（禁忌×2 + 等离子球）。第 5 球种全反馈通道接线（配色/拖尾/瞄准/辉光/受击紫光/炮塔色/音效/卡组图例）+ 延迟密度重建泛化 `applyHeavyDensity`。锻造区改自适应双列 `ceil(n/2)` 容 10 行。`selfcheck-meta-cards` 新增 ⑦ 段锁死"新球种不漏挂任一分支"+ 权衡不变量；deck-view 4→5 球种。全套 23/23 绿 |
| 2026-09-02 | 第 6 球种 + 12 轨（球种工坊多解锁扩展） | **熔核球**（`OrbType.Magma=5`）：走**通用累积路径**（不碰熔岩溅射分支，零回归），身份=超重重压 + 每钉 +75（>熔岩 60）+ 剥坚盾 3 层（`bulwarkPeelMagma`），经**球种工坊 Lv3** 解锁——验证 orbLab 从单解锁（Lv1 等离子）扩到多档位（Lv1+Lv3）。全反馈通道接线同 Plasma。**两数值轨**：商道 bargain（gold←Lv2，商店价 -8%/级封顶 -40%，`ShopDialog.finalPrice` 统一扣费+显示+可付）、攻城炮台 siege（castle←Lv4，炮塔子弹 +20%/级，`TurretController` 命中乘 `(1+getSiegeBonus)`）。锻造区改 **1/2/3 列自适应**（≤4/≤10/>10），三列窄行走紧凑模式（省效果文案）。`selfcheck-meta-cards` ⑦ 段扩至双球种全分支 + bargain/siege 行为真跑；boss-behaviors/funnel-orb 透传断言放宽首参。全套 23/23 绿 |
| 2026-09-02 | 第 7 球种 + 解锁总览预览（方向 2/3 续） | **吸血球**（`OrbType.Leech=6`）：走**普通物理**（非重球，不碰延迟密度分支），身份=**命中后治疗城堡**（伤害 25% 转要塞生命，`TurretController` 单一投递点命中后 `CastleController.heal`，不改伤害分配→零回归），经**球种工坊 Lv5** 封顶解锁——orbLab 成三档功能互补（Lv1 等离子反盾 / Lv3 熔核反 Boss / Lv5 吸血续航）。回血倍率 `OrbBalance.leechHealRatio` 单一来源。**收尾③**：锻造区加 **📖 解锁总览切换**——复用现有行节点，预览模式行显「名称·效果/describe」（含 🔒 前置），购买模式显 Lv+价格，预览态点击不扣费（`_forgePreview` 守卫 `onForgeRowClick`）；解决三列紧凑模式看不到效果文案的问题，零布局改动。`selfcheck-meta-cards` ⑦ 段扩至三球种全分支 + Leech 回血钩子 + 非重球不变量 + orbLab Lv5 describe；meta-reward 补预览切换断言 + applyMetaBonus 七球种全覆盖；deck-view 6→7。全套 23/23 绿 |
| 2026-09-02 | 禁忌三档 + 吸血飘字（方向 2/3 续） | **禁忌卡包 Lv5 封顶卡「不朽要塞」**（`forb_immortal`，`MaxHp` +80）：与奇点（进攻 BuffHeavy）· 猎神（反精英 AntiElite）构成**攻/杀/守三轴**，复用既有 `MaxHp` 处理器（`increaseMaxHp`）零新结算钩子——验证 forbiddenPack 从双档扩到三档（与 orbLab 三档对称）。describe 补 Lv5→奇点+猎神+不朽。**收尾③**：吸血球回血加**翠绿飘字**「+N ❤」（`TurretController` 命中后 `FloatingTextManager.showText`，复用结算大字管线）。`selfcheck-meta-cards` ⑥ 段跨局卡 5→6 + forbiddenPack Lv5 describe 三档校验 + Leech 飘字断言。全套 23/23 绿，import 边 167→168 无循环 |
| 2026-09-07 | 方案B「钉板决策深化」三机制落地 | ① **边缘风险带**：每波最宽行最左/最右钉（±0.5px 容差）标记边缘高能（琥珀描边圈），`PegComponent.multiplier` 乘 `EDGE_ENERGY_MULT=1.5`，与镀金叠置时赏金 ×2（`EDGE_GILD_BOUNTY_MULT`）——「冒掉槽风险换双倍金」显式赌注；② **过热钉**：每波对普通钉 Fisher-Yates 掷 3 颗（金描边圈），该次撞钉能量 ×3（`OrbController` 撞前捕获 `peg.isOverheated`，`onHit` 受击即熄）+「过热 ×3」跳字；③ **连击热流**：同次飞行第 N 撞伤害 ×(1+0.1(N-1)) 封顶 ×2（`comboHeatMult`），乘区与漏斗同层在入槽开火兑现（不进 `accumulatedDamage`，伤害快照语义不变）；「连击 ×N」里程碑跳字（4/8/11）+ `OrbView.setHeatTint` 本体色向炽橙渐变（`initOrbType` 复位）。雷球 hitCount 语义核实无漂移（连击追发门仍计撞钉数）。自检 `selfcheck-card-effects` ④段 + `selfcheck-peg-soft-reset` 版型轮换/过热形状锁定，全套 38 脚本全绿 |

